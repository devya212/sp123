package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Customer;

@Controller
public class CustomerController {
	
	@RequestMapping("/RegisterCustomer")	
	public ModelAndView request1(Customer customer)
	{
		//customer.setCustname("aaaa");
		return new ModelAndView("customerform");
	}
	
	@RequestMapping("/saveCustomer")
	public ModelAndView request2(Customer customer)
	{
		return new ModelAndView("result","cust",customer);
	}
}
